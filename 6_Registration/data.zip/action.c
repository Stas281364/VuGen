Action()
{

	lr_start_transaction("Full_transaction_Regisrtation");

	lr_start_transaction("1_transaction_ToWebTours");

	lr_end_transaction("1_transaction_ToWebTours",LR_AUTO);

	lr_start_transaction("2_transaction_SingUp");

	lr_end_transaction("2_transaction_SingUp",LR_AUTO);

	lr_start_transaction("3_transaction_Customer_Profile");

	lr_end_transaction("3_transaction_Customer_Profile",LR_AUTO);

	lr_end_transaction("Full_transaction_Regisrtation",LR_AUTO);

	return 0;
}